USE [ProjectManager]
GO

INSERT INTO [dbo].[User]
           ([FName]
           ,[LName]
           ,[EmpId])
     VALUES
           ('Lokesh',
           'Karthik',
           101)
GO

INSERT INTO [dbo].[User]
           ([FName]
           ,[LName]
           ,[EmpId])
     VALUES
           ('Lakshmi',
           'Narasimman',
           102)
GO

INSERT INTO [dbo].[User]
           ([FName]
           ,[LName]
           ,[EmpId])
     VALUES
           ('Anbu',
           'Arasan',
           103)
GO

INSERT INTO [dbo].[User]
           ([FName]
           ,[LName]
           ,[EmpId])
     VALUES
           ('Guru',
           'Moorthy',
           104)
GO

INSERT INTO [dbo].[User]
           ([FName]
           ,[LName]
           ,[EmpId])
     VALUES
           ('Srini',
           'Vasan',
           105)
GO
GO

INSERT INTO [dbo].[Project]
           ([ProjectManagerId]
           ,[Project]
           ,[StartDate]
           ,[EndDate]
           ,[Priority]
           ,[IsActive])
     VALUES
           (1,
           'Sales Invoicing',
           '2016-03-16',
           '2020-03-16',
           1,
           1)
GO

INSERT INTO [dbo].[Project]
           ([ProjectManagerId]
           ,[Project]
           ,[StartDate]
           ,[EndDate]
           ,[Priority]
           ,[IsActive])
     VALUES
           (2,
           'All in All',
           '2012-12-10',
           '2025-06-29',
           1,
           1)
GO

INSERT INTO [dbo].[Project]
           ([ProjectManagerId]
           ,[Project]
           ,[StartDate]
           ,[EndDate]
           ,[Priority]
           ,[IsActive])
     VALUES
           (3,
           'PI',
           '2015-11-20',
           '2021-09-11',
           1,
           1)
GO

INSERT INTO [dbo].[Project]
           ([ProjectManagerId]
           ,[Project]
           ,[StartDate]
           ,[EndDate]
           ,[Priority]
           ,[IsActive])
     VALUES
           (4,
           'TM',
           '2013-07-20',
           '2019-03-21',
           0,
           0)
GO


INSERT INTO [dbo].[Project]
           ([ProjectManagerId]
           ,[Project]
           ,[StartDate]
           ,[EndDate]
           ,[Priority]
           ,[IsActive])
     VALUES
           (5,
           'CS',
           '2012-09-20',
           '2019-02-10',
           0,
           0)
GO
GO

INSERT INTO [dbo].[Task]
           ([ParentTaskId]
           ,[Task]
           ,[StartDate]
           ,[EndDate]
           ,[Priority]
           ,[IsClosed]
           ,[IsParentTask]
           ,[ProjectId]
           ,[UserId])
     VALUES
           (1,
           'Release 1',
           '2018-06-06',
           '2019-06-12',
           5,
           1,
           0,
          2,
           1)
GO


INSERT INTO [dbo].[Task]
           ([ParentTaskId]
           ,[Task]
           ,[StartDate]
           ,[EndDate]
           ,[Priority]
           ,[IsClosed]
           ,[IsParentTask]
           ,[ProjectId]
           ,[UserId])
     VALUES
           (2,
           'Release 2',
           '2017-02-16',
           '2018-01-01',
           3,
           0,
           0,
          3,
           2)
GO

INSERT INTO [dbo].[Task]
           ([ParentTaskId]
           ,[Task]
           ,[StartDate]
           ,[EndDate]
           ,[Priority]
           ,[IsClosed]
           ,[IsParentTask]
           ,[ProjectId]
           ,[UserId])
     VALUES
           (3,
           'Release 3',
           '2018-05-26',
           '2019-01-01',
           2,
           1,
           0,
          4,
           3)
GO

INSERT INTO [dbo].[Task]
           ([ParentTaskId]
           ,[Task]
           ,[StartDate]
           ,[EndDate]
           ,[Priority]
           ,[IsClosed]
           ,[IsParentTask]
           ,[ProjectId]
           ,[UserId])
     VALUES
           (4,
           'Release 4',
           '2019-06-23',
           '2019-11-21',
           8,
           0,
           0,
          5,
           4)
GO

